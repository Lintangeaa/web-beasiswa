const dataStore = {
  Mahasiswa: [
    { nama: 'Lintang Dandung Prakoso', nim: '20103141', ipk: 3.75 },
    { nama: 'Syaiful Mufid', nim: '20103128', ipk: 3.52 },
    { nama: 'Budiman', nim: '20103022', ipk: 2.6 },
  ],
};

export default dataStore;
